clc; clear;
Num_Ant=16; Azi_Beam=-60:5:60; Elev_Beam = -30:10:30; Board_Num = 1:1:4;
Ant_idx = 0 : 1 : 15; Mag=30; unit_deg=5.625;
Weights = zeros(length(Azi_Beam), length(Elev_Beam), length(Board_Num), length(Ant_idx));
Angles = zeros(length(Azi_Beam), length(Elev_Beam), length(Board_Num), length(Ant_idx));


offset_channels = [
0	0	0	0;8.5	1.5	-3	6.3;16.1	7.9	16.2	18.25;3.1	-2.4	0.5	9.7
7.7	-0.1	0.8	8.35;23.6	12.7	12.7	17.35;11.7	8.3	1	15.15;8.4	2.7	1.8	12.75
-17.6	-15.5	-15.5	-2.9;-23.5	-20.9	-3	-0.85;-7.6	-15.8	4.7	4.15;-19.3	-20.1	-8.4	-5
-14	-15	-5.4	-2.1;0.4	-11.2	1.7	4.35;-7.8	-14.3	-4.5	10.05;-13.3	-10.6	-1.4	3.95
]';
% offset(2,:) = offset(2,:) - 4.575 ;
% offset(3,:) = offset(3,:) -	19.5625;
% offset(4,:) = offset(4,:) -63.425;

offset_boards = zeros(1,4);
offset_boards(2) = 12 ;
offset_boards(3) = 58;
offset_boards(4) = 100;

%19/25=> 30deg azi, 4/7=> 0deg elev, 
%find Angles(19,4,1,:)
for ii=1:length(Azi_Beam)
    for j= 1:length(Elev_Beam)
        for k = 1 : length(Board_Num)
            for channel = 1 : 1 : length(Ant_idx)
                %�Ʒ��� ���ʿ� pi ��� (j 2pi ~~�� 180/pi)
                Angles(ii,j,k,channel) =  (  (channel-1)*sin(Azi_Beam(ii)*pi/180)*cos(Elev_Beam(j)*pi/180) + ((k-1))*sin(Elev_Beam(j)*pi/180)  ) *180 - (offset_channels(k,channel) + offset_boards(k)) ;
                Angles(ii,j,k,channel) = rem(Angles(ii,j,k,channel),360);
                if (Angles(ii,j,k,channel) < 0)
                    Angles(ii,j,k,channel) = Angles(ii,j,k,channel) + 360;
                end
            end
        end
    end
end


Indices = round(Angles/unit_deg);
Indices_bin = strings(length(Azi_Beam), length(Elev_Beam), length(Board_Num), length(Ant_idx));

MSB = strings(length(Azi_Beam), length(Elev_Beam), length(Board_Num), length(Ant_idx));
LSB = strings(length(Azi_Beam), length(Elev_Beam), length(Board_Num), length(Ant_idx));

for ii=1:length(Azi_Beam)
    for j= 1:length(Elev_Beam)
        for k = 1 : length(Board_Num)
            for channel = 1 : 1 : length(Ant_idx)
                Indices_bin = (dec2bin(Indices(ii,j,k,channel),9));
                MSB(ii,j,k,channel) = convertCharsToStrings(Indices_bin(1:8));
                LSB(ii,j,k,channel) = convertCharsToStrings(strcat(Indices_bin(9), dec2bin(30,7)));
            end
        end
    end
end

% 3706 �����Ǿ����� ����־� ��, - 190805
% Common_Front=["0081","0018","40055","3860","2F7F","3616","3706","3142"]; Common_Rear="2802";
% 4801�� init�κ��� ���⼭ �������� �ʴ´�.

for ii=1:length(Azi_Beam)
    for j= 1:length(Elev_Beam)
        for k = 1 : length(Board_Num)
            % ���� �̸��� "Reg_Beam_" + azimuth + "," + elevation + "," + Board_num + ".txt" �÷� ���� �Ѵ�.
            Filename=['Reg_Beam_Azimuth_', num2str(Azi_Beam(ii)), '_Elevation_', num2str(Elev_Beam(j)), '_Board-Num_',num2str(Board_Num(k)) ,'.txt'];
            fileID=fopen(Filename,'w');
            for channel = 1 : 1 : 16
                fprintf(fileID,'%2s%2s\r\n',dec2hex(bin2dec(MSB(ii,j,k,channel)),2),dec2hex(bin2dec(LSB(ii,j,k,channel)),2) ); 
                % Elevation ����, Azimuth �״���, Board-Num ������.
            end
            fclose(fileID); % azi,elev,board ���� ���� �ϳ��� ���� ���� �ݱ�!!
        end
    end
end