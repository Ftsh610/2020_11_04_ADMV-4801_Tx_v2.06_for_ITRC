clc; clear;
Num_Ant=16; Azi_Beam=-60:5:60; Elev_Beam = -30:10:30; Board_Num = 1:1:4;
Ant_idx = 0 : 1 : 15; Mag=30; unit_deg=5.625;
Weights = zeros(length(Azi_Beam), length(Elev_Beam), length(Board_Num), length(Ant_idx));
Angles = zeros(length(Azi_Beam), length(Elev_Beam), length(Board_Num), length(Ant_idx));


offset = [
0	8.9	18.2	56.2;8.5	10.4	15.2	63.4;16.1	16.8	34.4	74.1;3.1	6.5	18.7	65;
7.7	8.8	19	64.2;23.6	21.6	30.9	73.7;11.7	17.2	19.2	70.6;8.4	11.6	20	68.4;
-17.6	-6.6	2.7	53.5;-23.5	-12	15.2	55.2;-7.6	-6.9	22.9	60;-19.3	-11.2	9.8	50.5;
-14	-6.1	12.8	52.9;0.4	-2.3	19.9	59.4;-7.8	-5.4	13.7	65.2;-13.3	-1.7	16.8	58.9;
]';
% offset(2,:) = offset(2,:) - 4.575 ;
% offset(3,:) = offset(3,:) -	19.5625;
% offset(4,:) = offset(4,:) -63.425;

offset_boards = zeros(1,4);
offset_boards(2) = 4.575 ;
offset_boards(3) = 19.5625;
offset_boards(4) = z

%19/25=> 30deg azi, 4/7=> 0deg elev, 
%find Angles(19,4,1,:)
for ii=1:length(Azi_Beam)
    for j= 1:length(Elev_Beam)
        for k = 1 : length(Board_Num)
            for channel = 1 : 1 : length(Ant_idx)
                %�Ʒ��� ���ʿ� pi ��� (j 2pi ~~�� 180/pi)
                Angles(ii,j,k,channel) =  (  (channel-1)*sin(Azi_Beam(ii)*pi/180)*cos(Elev_Beam(j)*pi/180) + ((k-1))*sin(Elev_Beam(j)*pi/180)  ) *180 - (offset(k,channel) + offset_boards(k));
                Angles(ii,j,k,channel) = rem(Angles(ii,j,k,channel),360);
                if (Angles(ii,j,k,channel) < 0)
                    Angles(ii,j,k,channel) = Angles(ii,j,k,channel) + 360;
                end
            end
        end
    end
end


Indices = round(Angles/unit_deg);
Indices_bin = strings(length(Azi_Beam), length(Elev_Beam), length(Board_Num), length(Ant_idx));

MSB = strings(length(Azi_Beam), length(Elev_Beam), length(Board_Num), length(Ant_idx));
LSB = strings(length(Azi_Beam), length(Elev_Beam), length(Board_Num), length(Ant_idx));

for ii=1:length(Azi_Beam)
    for j= 1:length(Elev_Beam)
        for k = 1 : length(Board_Num)
            for channel = 1 : 1 : length(Ant_idx)
                Indices_bin = (dec2bin(Indices(ii,j,k,channel),9));
                MSB(ii,j,k,channel) = convertCharsToStrings(Indices_bin(1:8));
                LSB(ii,j,k,channel) = convertCharsToStrings(strcat(Indices_bin(9), dec2bin(30,7)));
            end
        end
    end
end

% 3706 �����Ǿ����� ����־� ��, - 190805
% Common_Front=["0081","0018","40055","3860","2F7F","3616","3706","3142"]; Common_Rear="2802";
% 4801�� init�κ��� ���⼭ �������� �ʴ´�.

for ii=1:length(Azi_Beam)
    for j= 1:length(Elev_Beam)
        for k = 1 : length(Board_Num)
            % ���� �̸��� "Reg_Beam_" + azimuth + "," + elevation + "," + Board_num + ".txt" �÷� ���� �Ѵ�.
            Filename=['Reg_Beam_Azimuth_', num2str(Azi_Beam(ii)), '_Elevation_', num2str(Elev_Beam(j)), '_Board-Num_',num2str(Board_Num(k)) ,'.txt'];
            fileID=fopen(Filename,'w');
            for channel = 1 : 1 : 16
                fprintf(fileID,'%2s%2s\r\n',dec2hex(bin2dec(MSB(ii,j,k,channel)),2),dec2hex(bin2dec(LSB(ii,j,k,channel)),2) ); 
                % Elevation ����, Azimuth �״���, Board-Num ������.
            end
            fclose(fileID); % azi,elev,board ���� ���� �ϳ��� ���� ���� �ݱ�!!
        end
    end
end